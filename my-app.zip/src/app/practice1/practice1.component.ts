import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-practice',
  templateUrl: './practice1.component.html',
  styleUrls: ['./practice1.component.css']
})
export class PracticeComponent1 implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-123',
  templateUrl: './employee123.component.html',
  styleUrls: ['./employee123.component.css']
})
export class EmployeeComponent123 implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

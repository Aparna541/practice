import { Component , OnInit } from '@angular/core';

@Component({
  selector: 'app-practice',
  templateUrl:'./practice2.component.html',
  styleUrls:['./practice2.component.css'],
})

export class PracticeComponent2 implements OnInit {
    constructor() {}
    ngOnInit() {
        
    }
}
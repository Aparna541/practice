import {NgModule} from  '@angular/core';
import {CommonModule} from '@angular/common';
import {PracticeComponent2 } from './practice2.component';

@NgModule({
  declarations: [PracticeComponent2],
  imports: [CommonModule] ,
  exports : [PracticeComponent2]

})
 
export class PracticeModule2 {
    
}